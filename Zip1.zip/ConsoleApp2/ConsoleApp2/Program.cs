﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }

    public class Flight
    {
        public int FlightNumber { get; set; }
        
        public int PassengerCount { get; set; }

        public string Origin { get; set; }
        
        public string Destination { get; set; }

        public DateTime DepartureTime { get; set; }

        public DateTime ArrivalTime { get; set; }
    }

    public class FlightCollection : List<Flight>
    {
        SortingStrategy<Flight> sortingBy;

        public FlightCollection(SortingStrategy<Flight> strategy)
        {
            sortingBy = strategy;
        }

        public Flight[] Sort()
        {   
            return sortingBy.Sort(this);
        }   
    }

    public static class FlightsExtension
    {
        public static Flight[] Filter(this FlightCollection flights, Func<Flight, bool> filter)
        {
            List<Flight> result = new List<Flight>();
            flights.ForEach(flight =>
            {
                if (filter(flight))
                    result.Add(flight);
            });
            return result.ToArray();
        }
    }

    public abstract class SortingStrategy<T>
    {
        public abstract T[] Sort(IEnumerable<T> elements);
    }

    public class ByDepartureTime : SortingStrategy<Flight>
    {
        public override Flight[] Sort(IEnumerable<Flight> flights)
        {
            return flights.OrderBy(flight => flight.DepartureTime).ToArray();
        }
    }

    public class ByPassengerCount : SortingStrategy<Flight>
    {
        public override Flight[] Sort(IEnumerable<Flight> flights)
        {
            return flights.OrderBy(flight => flight.PassengerCount).ToArray();
        }
    }

    public class ByOrigin : SortingStrategy<Flight>
    {
        public override Flight[] Sort(IEnumerable<Flight> flights)
        {
            return flights.OrderBy(flight => flight.Origin).ToArray();
        }
    }

    public class ByDestination : SortingStrategy<Flight>
    {
        public override Flight[] Sort(IEnumerable<Flight> flights)
        {
            return flights.OrderBy(flight => flight.Destination).ToArray();
        }
    }
}
